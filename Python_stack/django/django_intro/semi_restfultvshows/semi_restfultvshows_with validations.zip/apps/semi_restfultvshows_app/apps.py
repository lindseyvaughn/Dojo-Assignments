from django.apps import AppConfig


class SemiRestfultvshowsAppConfig(AppConfig):
    name = 'semi_restfultvshows_app'
