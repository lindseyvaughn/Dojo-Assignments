from django.apps import AppConfig


class NGConfig(AppConfig):
    name = 'n_g'
