from flask import Flask, render_template, request, redirect
import datetime 

app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    strawberrytotal=request.form['strawberry']
    raspberrytotal=request.form['raspberry']
    appletotal=request.form['apple']
    first_name=request.form['first_name']
    last_name=request.form['last_name']
    student_id=request.form['student_id']

    
    today = datetime.datetime.now()
    current = today.strftime("%B %d, %y %I:%M %p")

    return render_template("checkout.html", strawberrytotal= int(strawberrytotal),raspberrytotal=int(raspberrytotal),appletotal=int(appletotal),first_name=first_name,last_name=last_name,student_id=student_id, current=current)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    